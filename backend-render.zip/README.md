# Resume AI Backend (Render-ready)

Endpoints:
- GET /health
- POST /generate

## Deploy on Render
- Build command: `pip install -r requirements.txt`
- Start command: `uvicorn main:app --host 0.0.0.0 --port 8080`
- Environment variable: `OPENAI_API_KEY=sk-...`
